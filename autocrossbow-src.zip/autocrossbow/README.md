# AutoCrossbow — Fabric 1.21

Auto crossbow mod với legit timing, bypass Grim/NCP.  
Tham khảo từ BOOST-FPS (by 30th6_ | KhangRelaX).

---

## Kiến trúc

```
AutoCrossbowClient          ← entry point, đăng ký key bind + tick event
├── CrossbowOptimizer       ← controller chính, chạy fire sequence
│   ├── TickSynchronizer    ← gate legit timing (awaitTickAfter)
│   ├── TargetManager       ← tìm target gần nhất mỗi tick
│   ├── InventoryUtil       ← scan hotbar/inventory, swap slot
│   └── InteractionUtil     ← tính angle, silent rotation
└── Mixins
    ├── ClientConnectionMixin      ← hook sau khi packet send (TAIL)
    ├── ClientPlayerEntityMixin    ← hook trước sendMovementPackets (HEAD)
    └── KeyboardInputMixin         ← snap movement khi đang rotate
```

---

## Tại sao bypass được Grim

### Vấn đề gốc
Grim kiểm tra **sequence** của packets trong một tick:
1. `UpdateSelectedSlot` → đổi slot
2. `PlayerInteractItem` → fire

Nếu cả hai đến trong cùng 1 tick (< 50ms), Grim flag là impossible
vì một human cần ít nhất 1 vanilla tick (50ms @ 20TPS) để react.

### Cách fix — `TickSynchronizer.awaitTickAfter()`

```
[Thread: main tick]
  tickSync.onClientTick()   ← bump tick counter, notifyAll()

[Thread: autocrossbow-worker]  
  selectHotbarSlot(slot)        ← gửi UpdateSelectedSlot packet
  preparedTick = tickSync.currentTick()
  awaitTickAfter(preparedTick)  ← BLOCK cho đến tick tiếp theo
  client.execute { interactItem() }  ← fire packet trên main thread
```

Kết quả: `UpdateSelectedSlot` đến server ở tick N, `PlayerInteractItem`
đến ở tick N+1. Đây là sequence hợp lệ cho cả Grim và NCP.

### Silent rotation
- Thay đổi `player.yaw` và `player.pitch` trực tiếp.
- Không gửi packet `TeleportConfirm` hay `PlayerLook` riêng.
- Packet `PlayerPosition` / `PlayerPositionAndLook` gửi tự động mỗi
  tick khi character move — angles được piggyback vào đó.
- Grim thấy look change đến trong movement packet → legit.

---

## Config (`AutoCrossbowConfig.kt`)

| Field | Default | Giải thích |
|---|---|---|
| `enabled` | true | Bật/tắt mod |
| `grimSync` | true | Bật legit tick timing |
| `extraDelayMs` | 0 | Thêm delay (ms) ngoài tick gate |
| `preferredSlot` | 0 | Hotbar slot ưu tiên (0-based) |
| `swapBack` | true | Về slot cũ sau khi fire |
| `bufferSlot` | 1 | Slot buffer để refill |
| `refillMode` | LEGIT | NONE / FAST / LEGIT |
| `silentRotation` | true | Silent camera align |
| `maxRange` | 64f | Range tìm target |

---

## Cách thêm Cloth Config GUI (optional)

```kotlin
// build.gradle — thêm dependency
modImplementation "me.shedaniel.cloth:cloth-config-fabric:15.0.140"

// Trong AutoCrossbowClient
import me.shedaniel.clothconfig2.api.ConfigBuilder
// Tạo screen trong ClientTickEvents hoặc một custom command
```

---

## Build

```bash
./gradlew build
# Output: build/libs/autocrossbow-1.0.0.jar
```

Yêu cầu Java 21+, Fabric Loader 0.16+, Fabric API 0.100.8+1.21.
