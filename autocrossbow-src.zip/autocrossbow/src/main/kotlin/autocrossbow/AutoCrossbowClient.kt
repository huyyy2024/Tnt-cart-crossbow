package autocrossbow

import autocrossbow.config.AutoCrossbowConfig
import autocrossbow.event.CrossbowRuntime
import autocrossbow.optimizer.CrossbowOptimizer
import autocrossbow.util.TickSynchronizer
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
import net.minecraft.client.option.KeyBinding
import net.minecraft.client.util.InputUtil
import org.lwjgl.glfw.GLFW

object AutoCrossbowClient : ClientModInitializer {

    val config = AutoCrossbowConfig()

    // Key bind: default G
    val activateKey: KeyBinding = KeyBindingHelper.registerKeyBinding(
        KeyBinding(
            "key.autocrossbow.activate",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            "category.autocrossbow"
        )
    )

    val tickSync = TickSynchronizer()

    lateinit var optimizer: CrossbowOptimizer

    override fun onInitializeClient() {
        optimizer = CrossbowOptimizer(config, tickSync, activateKey)

        // Register runtime singleton
        CrossbowRuntime.initialize(optimizer)

        // Tick loop
        ClientTickEvents.START_CLIENT_TICK.register { client ->
            tickSync.onClientTick()
            optimizer.onTick(client)
        }
    }
}
