package autocrossbow.config

/**
 * Config values — read from TOML or hardcoded defaults.
 * Swap out for Cloth Config / fzzy_config if you want an in-game GUI.
 */
class AutoCrossbowConfig {

    /** Enable the mod */
    var enabled: Boolean = true

    /**
     * grimSync: wait exactly one vanilla server tick between slot-select
     * and the fire packet. This is the core legit-timing trick from the
     * reference mod. When true, the packet sequence looks identical to a
     * human who is fast but physically plausible.
     */
    var grimSync: Boolean = true

    /**
     * Milliseconds to add on top of the grimSync tick wait.
     * 0 = tightest legit. 20–50 ms feels more human.
     */
    var extraDelayMs: Long = 0L

    /**
     * Hotbar slot (0-based) to look for charged crossbows first.
     * -1 = scan all hotbar slots.
     */
    var preferredSlot: Int = 0

    /**
     * After firing, swap back to the slot we were on before.
     */
    var swapBack: Boolean = true

    /**
     * Hotbar slot (0-based) used as the reload buffer.
     * The mod swaps a fresh crossbow from inventory into this slot
     * after the previous one fires.
     */
    var bufferSlot: Int = 1

    /**
     * NONE  = no auto-refill
     * FAST  = swap immediately after fire
     * LEGIT = delay by ~200 ms (mimics human hand speed)
     */
    var refillMode: RefillMode = RefillMode.LEGIT

    /** Silent rotation: rotate camera without visible snapping */
    var silentRotation: Boolean = true

    /** Max range (blocks) to consider a target */
    var maxRange: Float = 64f

    enum class RefillMode { NONE, FAST, LEGIT }
}
