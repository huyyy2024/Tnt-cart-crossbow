package autocrossbow.event

import autocrossbow.optimizer.CrossbowOptimizer

/**
 * Static bridge between mixins (Java-land) and the Kotlin optimizer.
 * Mixins can't easily reference Kotlin objects, so this provides
 * simple @JvmStatic accessors.
 */
object CrossbowRuntime {

    @Volatile
    private var optimizer: CrossbowOptimizer? = null

    fun initialize(opt: CrossbowOptimizer) {
        optimizer = opt
    }

    @JvmStatic
    fun onPacketSent() {
        optimizer?.onPacketSent()
    }
}
