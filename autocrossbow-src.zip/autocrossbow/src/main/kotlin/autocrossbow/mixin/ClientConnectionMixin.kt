package autocrossbow.mixin

import autocrossbow.event.CrossbowRuntime
import net.minecraft.network.ClientConnection
import net.minecraft.network.packet.Packet
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

/**
 * Hook at the TAIL of ClientConnection.send() so we know the moment
 * a packet actually leaves the client. Used for ACK-based timing.
 */
@Mixin(ClientConnection::class)
abstract class ClientConnectionMixin {

    // In 1.21 the send method is: send(Packet, PacketCallbacks)
    // yarn name: method_10739
    @Inject(
        method = ["send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;)V"],
        at = [At("TAIL")]
    )
    private fun autocrossbow_onSendPost(
        packet: Packet<*>,
        callbacks: Any?,   // PacketCallbacks — nullable
        ci: CallbackInfo
    ) {
        CrossbowRuntime.onPacketSent()
    }
}
