package autocrossbow.mixin

import autocrossbow.AutoCrossbowClient
import net.minecraft.client.network.ClientPlayerEntity
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

/**
 * Hook at the HEAD of sendMovementPackets() — this fires every client
 * tick just before position/look packets go out.
 *
 * We use it to signal the TickSynchronizer so background threads
 * waiting on awaitTickAfter() unblock at the correct moment, i.e.
 * right when the game is about to send the movement batch for this
 * tick. The fire packet therefore lands in the same network flush
 * window as the movement packets — identical to legit behavior.
 */
@Mixin(ClientPlayerEntity::class)
abstract class ClientPlayerEntityMixin {

    @Inject(
        method = ["sendMovementPackets"],
        at = [At("HEAD")]
    )
    private fun autocrossbow_beforeMovementPackets(ci: CallbackInfo) {
        // notifyAll is called inside onClientTick; this hook runs just
        // before movement packets so the tick counter is already bumped.
        // Nothing extra needed here — the START_CLIENT_TICK event fires
        // before sendMovementPackets in the vanilla tick order, so the
        // synchronizer is already up to date.
        //
        // If you want even tighter sync, move the tickSync.onClientTick()
        // call here instead of START_CLIENT_TICK:
        //   AutoCrossbowClient.tickSync.onClientTick()
        // Then comment out the ClientTickEvents registration in the entry point.
    }
}
