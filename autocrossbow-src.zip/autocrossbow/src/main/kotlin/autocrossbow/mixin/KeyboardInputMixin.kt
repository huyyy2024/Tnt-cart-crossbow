package autocrossbow.mixin

import autocrossbow.AutoCrossbowClient
import net.minecraft.client.input.KeyboardInput
import net.minecraft.client.input.Input
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

/**
 * During a silent rotation the optimizer sets a flag; here we zero out
 * the movement input so the player doesn't drift while the camera is
 * being repositioned server-side.
 *
 * This mirrors the reference mod's KeyboardInputMixin that reads
 * field_1343 / field_1342 (movementForward / movementSideways) and
 * rounds them, ensuring no fractional movement values leak out during
 * the rotation window.
 */
@Mixin(KeyboardInput::class)
abstract class KeyboardInputMixin : Input() {

    @Inject(
        method = ["tick"],
        at = [At("TAIL")]
    )
    private fun autocrossbow_fixMovementDuringRotation(ci: CallbackInfo) {
        val optimizer = AutoCrossbowClient.optimizer
        if (optimizer.isSilentlyRotating()) {
            // Snap to nearest integer step to avoid anti-cheat detecting
            // sub-tick fractional movement while the look angle is being changed.
            movementForward = movementForward.round()
            movementSideways = movementSideways.round()
        }
    }

    private fun Float.round(): Float = Math.round(this).toFloat()
}
