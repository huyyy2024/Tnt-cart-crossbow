package autocrossbow.optimizer

import autocrossbow.config.AutoCrossbowConfig
import autocrossbow.util.InventoryUtil
import autocrossbow.util.InteractionUtil
import autocrossbow.util.TargetManager
import autocrossbow.util.TickSynchronizer
import net.minecraft.client.MinecraftClient
import net.minecraft.client.option.KeyBinding
import net.minecraft.util.Hand
import net.minecraft.util.Hand.MAIN_HAND
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Core optimizer.
 *
 * Fire sequence (grimSync = true):
 * 1. Key pressed
 * 2. Find charged crossbow slot
 * 3. SelectHotbar packet → slot change
 * 4. Record preparedTick = tickSync.currentTick()
 * 5. awaitTickAfter(preparedTick) — BLOCKS until next server tick
 * 6. PlayerInteractItem packet (the actual fire)
 * 7. Schedule refill if configured
 * 8. Swap back if configured
 *
 * Step 5 is what makes this legit: the fire packet arrives on the
 * tick AFTER the slot packet, which is the minimum possible gap for
 * a human — Grim and NCP both validate this ordering.
 */
class CrossbowOptimizer(
    private val config: AutoCrossbowConfig,
    private val tickSync: TickSynchronizer,
    private val activateKey: KeyBinding
) {

    private val executing = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "autocrossbow-worker").also { it.isDaemon = true }
    }

    val targetManager = TargetManager(config.maxRange)

    // Slot we were on before firing, for swap-back
    @Volatile private var previousSlot: Int = 0

    // True while a silent rotation is in progress — read by KeyboardInputMixin
    @Volatile private var silentlyRotating: Boolean = false
    fun isSilentlyRotating(): Boolean = silentlyRotating

    // ── tick loop ────────────────────────────────────────────────────────────

    fun onTick(client: MinecraftClient) {
        if (!config.enabled) return
        if (client.player == null || client.world == null) return

        // Update target every tick
        targetManager.tick()

        // Key edge-detect
        while (activateKey.wasPressed()) {
            triggerFire(client)
        }
    }

    // ── fire trigger ─────────────────────────────────────────────────────────

    private fun triggerFire(client: MinecraftClient) {
        if (!executing.compareAndSet(false, true)) return  // already running

        executor.execute {
            try {
                doFire(client)
            } finally {
                executing.set(false)
            }
        }
    }

    private fun doFire(client: MinecraftClient) {
        val player = client.player ?: return

        // ── 1. find charged crossbow ─────────────────────────────────────
        val targetSlot = InventoryUtil.findChargedCrossbowInHotbar(config.preferredSlot)
        if (targetSlot < 0) return  // nothing to fire

        // ── 2. record previous slot + switch ────────────────────────────
        previousSlot = player.inventory.selectedSlot
        if (targetSlot != player.inventory.selectedSlot) {
            InventoryUtil.selectHotbarSlot(targetSlot)
        }

        // ── 2b. silent rotation toward target ───────────────────────────
        // We set the angle now, before the tick gate. The movement packet
        // that fires on the next tick will carry these angles to the server
        // naturally — no separate look packet needed.
        val target = targetManager.current
        if (target != null && config.silentRotation) {
            val angles = InteractionUtil.calculateAngle(target)
            silentlyRotating = true
            client.execute {
                InteractionUtil.rotateSilent(angles[0], angles[1])
                silentlyRotating = false
            }
        }

        // ── 3. grim sync gate ────────────────────────────────────────────
        if (config.grimSync) {
            val preparedTick = tickSync.currentTick()
            val ok = tickSync.awaitTickAfter(preparedTick, 200L + config.extraDelayMs)
            if (!ok) return  // timeout — abort
        } else if (config.extraDelayMs > 0L) {
            Thread.sleep(config.extraDelayMs)
        }

        // ── 4. send fire packet ──────────────────────────────────────────
        sendFirePacket(client)

        // ── 5. swap-back ─────────────────────────────────────────────────
        if (config.swapBack && previousSlot != targetSlot) {
            // wait one tick so swap-back lands after fire
            if (config.grimSync) {
                val t = tickSync.currentTick()
                tickSync.awaitTickAfter(t, 200L)
            }
            InventoryUtil.selectHotbarSlot(previousSlot)
        }

        // ── 6. schedule refill ───────────────────────────────────────────
        scheduleRefill(targetSlot)
    }

    private fun sendFirePacket(client: MinecraftClient) {
        // Always dispatch the actual packet on the main client thread.
        // The background thread was only used for the WAIT (awaitTickAfter).
        // interactItem() in 1.21 handles: sequence number, arm swing,
        // attack cooldown reset, and the PlayerInteractItemC2SPacket send.
        client.execute {
            val p = client.player ?: return@execute
            val stack = p.inventory.getStack(p.inventory.selectedSlot)
            if (!InventoryUtil.isChargedCrossbow(stack)) return@execute
            client.interactionManager?.interactItem(p, Hand.MAIN_HAND)
        }
    }

    // ── refill logic ─────────────────────────────────────────────────────────

    private fun scheduleRefill(firedSlot: Int) {
        if (config.refillMode == AutoCrossbowConfig.RefillMode.NONE) return

        val delayMs = when (config.refillMode) {
            AutoCrossbowConfig.RefillMode.FAST  -> 50L
            AutoCrossbowConfig.RefillMode.LEGIT -> 180L + (20..60).random()
            else -> return
        }

        executor.execute {
            Thread.sleep(delayMs)
            doRefill(firedSlot)
        }
    }

    private fun doRefill(hotbarSlot: Int) {
        val client = MinecraftClient.getInstance()
        val invSlot = InventoryUtil.findChargedCrossbowInInventory()
        if (invSlot < 0) return  // nothing to refill from

        client.execute {
            InventoryUtil.swapInventoryToHotbar(invSlot, hotbarSlot)
        }
    }

    // ── packet hook callbacks (called from mixins) ────────────────────────

    /**
     * Called from ClientConnectionMixin after any packet is sent.
     * Currently used as a hook point for future ACK-based sync.
     */
    fun onPacketSent() {
        // Reserved — could implement ACK-based tick sync here
    }
}
