package autocrossbow.util

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Simple gate: when [blocked] is true, the mixin that reads keyboard
 * input can suppress the vanilla use-item action to prevent the player
 * from accidentally triggering a manual load/fire while the optimizer
 * is mid-sequence.
 */
object InputBlocker {
    private val _blocked = AtomicBoolean(false)

    val blocked: Boolean get() = _blocked.get()

    fun block()   { _blocked.set(true)  }
    fun unblock() { _blocked.set(false) }

    /**
     * Run [action] with input blocked, then unblock.
     * Safe to call from any thread.
     */
    inline fun <T> withBlock(action: () -> T): T {
        block()
        return try { action() } finally { unblock() }
    }
}
