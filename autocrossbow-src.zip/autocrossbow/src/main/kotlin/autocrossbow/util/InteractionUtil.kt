package autocrossbow.util

import net.minecraft.client.MinecraftClient
import net.minecraft.entity.Entity
import net.minecraft.util.math.Vec3d
import kotlin.math.*

object InteractionUtil {

    /**
     * Calculate [yaw, pitch] in degrees from the client player's eye
     * position to [target]'s eye position.
     */
    fun calculateAngle(target: Entity): FloatArray {
        val client = MinecraftClient.getInstance()
        val player = client.player ?: return floatArrayOf(0f, 0f)

        val origin = player.eyePos
        val dest = target.eyePos

        val dx = dest.x - origin.x
        val dy = dest.y - origin.y
        val dz = dest.z - origin.z

        val dist = sqrt(dx * dx + dz * dz)

        val yaw   = Math.toDegrees(atan2(-dx, dz)).toFloat()
        val pitch = Math.toDegrees(-atan2(dy, dist)).toFloat()

        return floatArrayOf(yaw, pitch)
    }

    /**
     * True if [target] is within [fovDegrees] of the player's current
     * look direction.
     */
    fun isInFov(target: Entity, fovDegrees: Float): Boolean {
        val client = MinecraftClient.getInstance()
        val player = client.player ?: return false
        val angles = calculateAngle(target)
        val dyaw   = angleDiff(angles[0], player.yaw)
        val dpitch = angleDiff(angles[1], player.pitch)
        return abs(dyaw) < fovDegrees && abs(dpitch) < fovDegrees
    }

    /** Signed angular difference, clamped to [-180, 180]. */
    private fun angleDiff(a: Float, b: Float): Float {
        var d = a - b
        while (d >  180f) d -= 360f
        while (d < -180f) d += 360f
        return d
    }

    /**
     * Apply silent rotation: update the player's yaw/pitch directly
     * WITHOUT sending a separate look packet. The movement packet that
     * fires every tick carries the new angles, so the server sees them
     * on the next tick — same as a human who moved the mouse.
     */
    fun rotateSilent(yaw: Float, pitch: Float) {
        val client = MinecraftClient.getInstance()
        val player = client.player ?: return
        player.yaw   = yaw
        player.pitch = pitch
        // The head yaw needs to match for the server hitbox to line up
        player.headYaw = yaw
    }
}
