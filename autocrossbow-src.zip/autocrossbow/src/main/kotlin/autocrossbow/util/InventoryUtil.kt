package autocrossbow.util

import net.minecraft.client.MinecraftClient
import net.minecraft.component.DataComponentTypes
import net.minecraft.component.type.ChargedProjectilesComponent
import net.minecraft.item.CrossbowItem
import net.minecraft.item.ItemStack
import net.minecraft.item.Items
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket
import net.minecraft.screen.slot.SlotActionType

object InventoryUtil {

    private const val HOTBAR_SIZE = 9

    /**
     * Returns the hotbar slot index (0-8) of a charged crossbow,
     * preferring [preferredSlot]. Returns -1 if none found.
     */
    fun findChargedCrossbowInHotbar(preferredSlot: Int): Int {
        val client = MinecraftClient.getInstance()
        val inventory = client.player?.inventory ?: return -1

        // Try preferred first
        if (preferredSlot in 0 until HOTBAR_SIZE) {
            val stack = inventory.getStack(preferredSlot)
            if (isChargedCrossbow(stack)) return preferredSlot
        }

        // Scan rest of hotbar
        for (slot in 0 until HOTBAR_SIZE) {
            if (slot == preferredSlot) continue
            val stack = inventory.getStack(slot)
            if (isChargedCrossbow(stack)) return slot
        }
        return -1
    }

    /**
     * Returns the first inventory slot (9-35) that contains a charged
     * crossbow. Returns -1 if none found.
     */
    fun findChargedCrossbowInInventory(): Int {
        val client = MinecraftClient.getInstance()
        val inventory = client.player?.inventory ?: return -1
        for (slot in HOTBAR_SIZE..35) {
            if (isChargedCrossbow(inventory.getStack(slot))) return slot
        }
        return -1
    }

    /**
     * Find any uncharged crossbow in inventory (for the reload buffer).
     */
    fun findUnchargedCrossbowInInventory(): Int {
        val client = MinecraftClient.getInstance()
        val inventory = client.player?.inventory ?: return -1
        for (slot in HOTBAR_SIZE..35) {
            val stack = inventory.getStack(slot)
            if (stack.item is CrossbowItem && !isChargedCrossbow(stack)) return slot
        }
        return -1
    }

    /**
     * Silently change the selected hotbar slot by sending a packet
     * directly — does NOT call the normal method so we can call it
     * from a background thread and have it land at the right tick.
     */
    fun selectHotbarSlot(slot: Int) {
        val client = MinecraftClient.getInstance()
        if (slot !in 0 until HOTBAR_SIZE) return
        client.player?.inventory?.selectedSlot = slot
        client.networkHandler?.sendPacket(UpdateSelectedSlotC2SPacket(slot))
    }

    /**
     * Move an item from an inventory slot to a hotbar slot using the
     * pick-block click action (action type SWAP, button = hotbar slot).
     * This is the same call the reference mod uses via
     * interactionManager.clickSlot with SWAP.
     */
    fun swapInventoryToHotbar(inventorySlot: Int, hotbarSlot: Int) {
        val client = MinecraftClient.getInstance()
        val player = client.player ?: return
        val handler = player.currentScreenHandler

        // In 1.21 the player's own inventory screen handler maps:
        //   hotbar  slots 0-8   → screen slots 36-44
        //   main inv slots 9-35 → screen slots 9-35
        // When no container is open (PlayerScreenHandler), use these offsets.
        val screenSlot = when {
            inventorySlot in 0 until HOTBAR_SIZE -> inventorySlot + 36
            inventorySlot in HOTBAR_SIZE..35      -> inventorySlot
            else -> return
        }

        client.interactionManager?.clickSlot(
            handler.syncId,
            screenSlot,
            hotbarSlot,
            SlotActionType.SWAP,
            player
        )
    }

    // ── helpers ─────────────────────────────────────────────────────────────

    fun isChargedCrossbow(stack: ItemStack): Boolean {
        if (stack.item !is CrossbowItem) return false
        // DataComponentTypes.CHARGED_PROJECTILES is available from 1.20.5+
        val projectile = stack.get(DataComponentTypes.CHARGED_PROJECTILES) ?: return false
        return !projectile.isEmpty
    }

    fun isCrossbow(stack: ItemStack): Boolean = stack.item is CrossbowItem

    /** True if the stack is an arrow or firework that can load a crossbow. */
    fun isProjectile(stack: ItemStack): Boolean =
        stack.item == Items.ARROW ||
        stack.item == Items.TIPPED_ARROW ||
        stack.item == Items.SPECTRAL_ARROW ||
        stack.item == Items.FIREWORK_ROCKET
}
