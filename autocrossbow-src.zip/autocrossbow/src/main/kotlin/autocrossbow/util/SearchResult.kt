package autocrossbow.util

/**
 * Result of a hotbar/inventory scan.
 *
 * @param found  true if the item was located
 * @param slot   the slot index (0-based); -1 when not found
 */
data class SearchResult(val found: Boolean, val slot: Int) {
    companion object {
        val MISSING = SearchResult(found = false, slot = -1)
        fun at(slot: Int) = SearchResult(found = true, slot = slot)
    }
}
