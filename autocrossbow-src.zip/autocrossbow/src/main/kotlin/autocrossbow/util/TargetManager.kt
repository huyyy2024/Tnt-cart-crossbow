package autocrossbow.util

import net.minecraft.client.MinecraftClient
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.predicate.entity.EntityPredicates

/**
 * Finds and caches the nearest hostile/visible player target.
 * Called every tick from the optimizer when a target is needed.
 */
class TargetManager(private val maxRange: Float) {

    @Volatile var current: PlayerEntity? = null
        private set

    fun tick() {
        val client = MinecraftClient.getInstance()
        val player = client.player ?: run { current = null; return }
        val world  = client.world  ?: run { current = null; return }

        current = world.getPlayers(EntityPredicates.EXCEPT_SPECTATOR)
            .asSequence()
            .filter { it != player }
            .filter { it.distanceTo(player) <= maxRange }
            .filter { player.canSee(it) }
            .minByOrNull { it.distanceTo(player) }
    }

    fun hasTarget(): Boolean = current != null
}
