package autocrossbow.util

import java.util.concurrent.TimeUnit

/**
 * Mirrors the reference mod's ClientTickSynchronizer.
 *
 * Purpose: let a background thread block until the NEXT vanilla
 * client tick fires, then unblock. This guarantees that the
 * PlayerInteractItem packet is dispatched on the same tick as the
 * slot-change and look packets — exactly the sequence a legit fast
 * player would produce.
 *
 * Without this, spamming fire from a background thread can produce
 * packet orderings that anti-cheats flag.
 */
class TickSynchronizer {

    private val monitor = Object()

    @Volatile
    private var tick: Long = 0L

    /** Called from the main client tick (START_CLIENT_TICK event). */
    fun onClientTick() {
        synchronized(monitor) {
            tick++
            monitor.notifyAll()
        }
    }

    /** Current tick counter. */
    fun currentTick(): Long = tick

    /**
     * Block the calling thread until tick > [preparedTick] OR
     * [timeoutMs] elapses. Returns true if a new tick was observed.
     *
     * Usage:
     *   val t = tickSync.currentTick()
     *   // ... prepare slot + angle ...
     *   tickSync.awaitTickAfter(t, 200)   // wait for server tick gate
     *   // ... send fire packet ...
     */
    fun awaitTickAfter(preparedTick: Long, timeoutMs: Long): Boolean {
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs.coerceAtLeast(1L))
        synchronized(monitor) {
            while (tick <= preparedTick) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0L) return false
                try {
                    TimeUnit.NANOSECONDS.timedWait(monitor, remaining)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return false
                }
            }
        }
        return true
    }
}
